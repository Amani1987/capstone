export AUTH0_DOMAIN='newdeveloper.auth0.com'
export ALGORITHMS=['RS256']
export API_AUDIENCE='casting'
export DATABASE_URL="postgres://peqqpvjpwjowch:b124205ee5f72ec25c706e1434f424b55079faed7436821ca9df198e199d0215@ec2-52-202-22-140.compute-1.amazonaws.com:5432/daerr06qc2hf52"
export FLASK_APP=app.py
export FLASK_ENV=development